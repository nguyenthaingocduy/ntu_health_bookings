@extends('layouts.admin')

@section('title', 'Test Page')

@section('header', 'Test Page')

@section('content')
<div class="bg-white rounded-lg shadow-sm overflow-hidden">
    <div class="p-6">
        <h1 class="text-2xl font-semibold text-gray-900">Test Page</h1>
        <p class="mt-4">This is a test page to check if the route is working.</p>
    </div>
</div>
@endsection
