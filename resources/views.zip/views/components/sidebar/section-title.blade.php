@props(['title'])

<div class="px-4 mt-6 mb-3 text-xs font-semibold text-gray-400 uppercase tracking-wider">
    {{ $title }}
</div>
